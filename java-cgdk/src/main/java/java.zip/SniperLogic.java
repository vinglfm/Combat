import model.Game;
import model.Move;
import model.Trooper;
import model.World;


public final class SniperLogic extends BaseLogic {

	@Override
	public void action(Trooper self, World world, Game game, Move move) {
		// TODO Auto-generated method stub
		
	}

}
